#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "my_gl.h"
#include <QDebug>





MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);


}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::keyPressEvent(QKeyEvent *event)
{


    if (event->key() == Qt::Key_D) {
        //qDebug() <<y_inc;
        y_inc+=5;
    }

    if (event->key() == Qt::Key_A) {
        y_inc += -5.0f;
    }
    if (event->key() == Qt::Key_W) {
        //qDebug() <<y_inc;
        x_inc+=5;
    }

    if (event->key() == Qt::Key_S) {
        x_inc += -5.0f;
    }
    if (event->key() == Qt::Key_E) {
        //qDebug() <<y_inc;
        z_inc+=5;
    }

    if (event->key() == Qt::Key_Q) {
        z_inc += -5.0f;
    }
    ui->openGLWidget->setRotation(x_inc,y_inc,z_inc);


    if (event->key() == Qt::Key_Up) {
        ui->openGLWidget->setGeometry(100,100,0,0);
        qDebug("test");
    }

}

void MainWindow::on_pushButton_clicked()
{
    close();
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    lastX = event->x();
    lastY = event->y();
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    float xAtRelease = event->x();
    float yAtRelease = event->y();

    float dx = xAtRelease - lastX;
    float dy = yAtRelease - lastY;

    float x = ui->openGLWidget->x();
    float y = ui->openGLWidget->y();

    //ui->openGLWidget->glTranslated(QPoint(x + dx, y + dy));



    lastX = event->x();
    lastY = event->y();

}
